### **Whimscape 1.16.5_r2** (2025 May 20)
- added soul lantern emissive texture
- changed block and item models:
    - brewing stand bottles
    - lantern display tweaks
- changed block textures:
    - brewing stand bottles
    - end portal frame eye
    - lantern emissive texture
    - sunflower
    - torch flame animations
    - composter/note block/jukebox/scaffolding top: slight tweak to a single color
- changed item textures:
    - chorus fruits
    - cookie
    - buckets
    - sunflower
    - torch flame animations
    - tiny tweaks to some other items
- changed entities: tweaks to cow, ghast, shield and slime textures
- removed unused waxed copper item models


### **Whimscape 1.16.5_r1** (2025 Apr 23)
- backport based on 1.17_r2 and 1.19-1.19.2_r3
